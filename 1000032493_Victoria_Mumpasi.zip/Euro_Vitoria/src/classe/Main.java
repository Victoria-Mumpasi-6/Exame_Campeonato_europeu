package classe;
import DAO.*;
import java.util.List;

public class Main {

    private static JogadorDAO jogadorDao = new JogadorDAO();
    private static  SelecaoDAO selecaoDao = new SelecaoDAO();
    private static EstadioDAO estadioDao = new EstadioDAO();
    private static CidadeDAO cidadeDao = new CidadeDAO();
    //private static JogoDAO JogoDao = new JogoDAO();
    //private static GolsDAO golsDao = new GolsDAO();
    //private static CartoesDAO cartoesDao = new CartoesDAO();
    //private static GrupoDAO crudGrupo = new GrupoDAO();
    //private static ClassificacaoDAO crudClassificacao = new ClassificacaoDAO();
    private static EstatisticasEquipeDAO estatisticasEquipeDao = new EstatisticasEquipeDAO();
    private static EstatisticasJogadorDAO estatisticasJogadorDao = new EstatisticasJogadorDAO();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            System.out.println("Menu Principal:");
            System.out.println("0. Gerenciar Jogador");
            System.out.println("1. Gerenciar Selecao");
            System.out.println("2. Gerenciar Estadio");
            System.out.println("3. Gerenciar Cidade");
            System.out.println("4. Simular Jogo");
            System.out.println("5. Listar Melhores Marcadores");
            System.out.println("6. Gerenciar Estatisticas");
            System.out.println("7. Listar Grupos");
            System.out.println("8. Sair");

            int choice = InputUtils.getInt("Escolha uma opção: ");

            switch (choice) {
                case 0:
                    gerirJogador();
                    break;
                case 1:
                    gerirSelecao();
                    break;
                case 2:
                    gerirEstadio();
                    break;
                case 3:
                    gerirCidade();
                    break;
                case 4:
                    simularJogo();
                    break;
                case 5:
                    listarMelhoresMarcadores();
                    break;
                case 6:
                    estatisticas();
                    break;
                case 7:
                    listarGrupos();
                    break;
                case 8:
                    running = false;
                    InputUtils.closeScanner();
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
    

    private static void gerirJogador() {
        System.out.println("...................Gerenciar Jogador............");
        System.out.println("1. Adicionar Jogador");
        System.out.println("2. Consultar Jogador por Nome");
        System.out.println("3. Atualizar Jogador");
        System.out.println("4. Deletar Jogador");
        System.out.println("5. Voltar");

        int choice = InputUtils.getInt("Escolha uma opção: ");

        switch (choice) {
            case 1:
                adicionarJogador();
                break;
            case 2:
                consultarJogadorPorNome();
                break;
            case 3:
                atualizarJogador();
                break;
            case 4:
                deletarJogador();
                break;
            case 5:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }

    private static void adicionarJogador() {
        String nome = InputUtils.getString("Nome do jogador: ");
        String posicao = InputUtils.getString("Posição do jogador: ");
        int selecaoId = InputUtils.getInt("ID da seleção: ");

        Jogador jogador = new Jogador(0, nome, posicao, selecaoId);
        jogadorDao.adicionarJogador(jogador);
    }

    private static void consultarJogadorPorNome() {
        String nome = InputUtils.getString("Nome do jogador: ");
        jogadorDao.consultarPorNome(nome);
    }

    private static void atualizarJogador() {
        int id = InputUtils.getInt("ID do jogador: ");
        String nome = InputUtils.getString("Nome do jogador: ");
        String posicao = InputUtils.getString("Posição do jogador: ");
        int selecaoId = InputUtils.getInt("ID da seleção: ");

        Jogador jogador = new Jogador(id, nome, posicao, selecaoId);
        jogadorDao.atualizarJogador(jogador);
    }

    private static void deletarJogador() {
        int id = InputUtils.getInt("ID do jogador: ");
        jogadorDao.deletarJogador(id);
    }

    private static void gerirSelecao() {
        System.out.println("...................Gerenciar Selecao................");
        System.out.println("1. Adicionar Selecao");
        System.out.println("2. Consultar selecao por Nome");
        System.out.println("3. Atualizar Selecao");
        System.out.println("4. Deletar Selecao");
        System.out.println("5. Voltar");

        int choice = InputUtils.getInt("Escolha uma opção: ");

        switch (choice) {
            case 1:
                adicionarSelecao();
                break;
            case 2:
                consultarSelecaoPorNome();
                break;
            case 3:
                atualizarSelecao();
                break;
            case 4:
                deletarSelecao();
                break;
            case 5:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }
    
    private static void adicionarSelecao() {
        String nome = InputUtils.getString("Nome da Selecao: ");
        int paisId = InputUtils.getInt("Id da seleção: ");
        int grupoId = InputUtils.getInt("Grupo Id: ");
        Selecao selecao = new Selecao(0, nome, paisId, grupoId);
        selecaoDao.adicionarSelecao(selecao);
    }
    
    private static void consultarSelecaoPorNome() {
        String nome = InputUtils.getString("Nome da selecao: ");
        selecaoDao.consultarPorNome(nome);
    }
    
    private static void atualizarSelecao() {
        int id = InputUtils.getInt("ID da selecao: ");
        String nome = InputUtils.getString("Nome do jogador: ");
        int paisId = InputUtils.getInt("ID da seleção: ");
        int grupoId = InputUtils.getInt("Grupo Id: ");
        Selecao selecao = new Selecao(id, nome, paisId, grupoId);
        selecaoDao.atualizarSelecao(selecao);
    }
    
    private static void deletarSelecao() {
        int id = InputUtils.getInt("ID da Selecao: ");
        selecaoDao.deletarSelecao(id);
    }
    
    
    private static void gerirEstadio() {
        System.out.println("...................Gerenciar Estadio...................");
        System.out.println("1. Adicionar Estadio");
        System.out.println("2. Consultar Estadio por Nome");
        System.out.println("3. Atualizar Estadio");
        System.out.println("4. Deletar Estadio");
        System.out.println("5. Voltar");

        int choice = InputUtils.getInt("Escolha uma opção: ");

        switch (choice) {
            case 1:
                adicionarEstadio();
                break;
            case 2:
                consultarEstadioPorNome();
                break;
            case 3:
                atualizarEstadio();
                break;
            case 4:
                deletarEstadio();
                break;
            case 5:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }
    
    private static void adicionarEstadio() {
        String nome = InputUtils.getString("Nome do estadio: ");
        int cidadeId = InputUtils.getInt("cidade do estadio: ");
        int capacidade = InputUtils.getInt("Capacidade do estadio: ");

        Estadio estadio = new Estadio(0, nome, cidadeId, capacidade);
        estadioDao.atualizarEstadio(estadio);
    }
    
    private static void consultarEstadioPorNome() {
        String nome = InputUtils.getString("Nome do estadio: ");
        estadioDao.consultarPorNome(nome);
    }
    
    private static void atualizarEstadio() {
        int id = InputUtils.getInt("ID do estadio: ");
        String nome = InputUtils.getString("Nome do estadio: ");
        int cidadeId = InputUtils.getInt("cidade do estadio: ");
        int capacidade = InputUtils.getInt("Capacidade do estadio: ");

        Estadio estadio = new Estadio(id, nome, cidadeId, capacidade);
        estadioDao.atualizarEstadio(estadio);
    }
    
    private static void deletarEstadio() {
        int id = InputUtils.getInt("ID do estadio: ");
        estadioDao.deletarEstadio(id);
    }
    

    private static void gerirCidade() {
        System.out.println(".................Gerenciar Cidade..................");
        System.out.println("1. Adicionar Cidade");
        System.out.println("2. Consultar Cidade por Nome");
        System.out.println("3. Atualizar Cidade");
        System.out.println("5. Voltar");

        int choice = InputUtils.getInt("Escolha uma opção: ");

        switch (choice) {
            case 1:
                adicionarCidade();
                break;
            case 2:
                consultarCidadePorNome();
                break;
            case 3:
                atualizarCidade();
                break;
            case 4:
                deletarCidade();
                break;
            case 5:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }
    
    private static void adicionarCidade() {
        String nome = InputUtils.getString("Nome da cidade: ");
        int paisId = InputUtils.getInt("Id do Pais: ");

        Cidade cidade = new Cidade(0, nome, paisId);
        cidadeDao.adicionarCidade(cidade);
    }
    
    private static void consultarCidadePorNome() {
        String nome = InputUtils.getString("Nome da cidade: ");
        cidadeDao.consultarPorNome(nome);
    }
    
    private static void atualizarCidade() {
        int id = InputUtils.getInt("ID da cidade: ");
        String nome = InputUtils.getString("Nome da cidade: ");
        int paisId = InputUtils.getInt("Id do Pais: ");

        Cidade cidade = new Cidade(id, nome, paisId);
        cidadeDao.atualizarCidade(cidade);
    }
    
    private static void deletarCidade() {
        int id = InputUtils.getInt("ID da cidade: ");
        cidadeDao.deletarCidade(id);
    }

    private static void simularJogo() {
    	System.out.println("..............................Simuacao das fases do Euro...........................");
        System.out.println("");
        Simulacao simulacao = new Simulacao();
        
    	System.out.println("........................Simuladndo fase de Grupo(4 grupos)..........................");
        System.out.println("");
        simulacao.simularFaseDeGrupos();
        
        System.out.println("");
        System.out.println("......................Simulando Eliminatorias(8 selecoes)...........................");

        List<Selecao> selecoesClassificadasParaQuartas = simulacao.obterSelecoesClassificadasParaQuartas();
        System.out.println("Número de seleções classificadas para as quartas de final: " + selecoesClassificadasParaQuartas.size());
        
        System.out.println("");
        List<Selecao> vencedoresQuartas = simulacao.simularQuartas(selecoesClassificadasParaQuartas);
        System.out.println("");
        System.out.println("..................Simulando Semi Finais(4 Seleções)..................................");
        
        System.out.println("Número de seleções classificadas para as meias finais: " + vencedoresQuartas.size());
        List<Selecao> vencedoresSemifinais = simulacao.simularSemifinais(vencedoresQuartas);
        System.out.println("");
        System.out.println("...........................Simulando Final(2 Seleções)................................");

        System.out.println("Número de seleções classificadas para a final: " + vencedoresSemifinais.size());
        System.out.println("");
                Selecao campeao = simulacao.simularFinal(vencedoresSemifinais);
        System.out.println("Campeão: " + campeao.getNome());
        System.out.println("");
    }


    
    private static void listarMelhoresMarcadores() {
        System.out.println("Listar Melhores Marcadores:");
        List<Jogador> melhoresMarcadores = jogadorDao.consultarMelhoresMarcadores();
        for (Jogador jogador : melhoresMarcadores) {
            System.out.println(jogador.getNome() + " - Gols: " + jogador.getGols());
        }
    }

    
    private static void listarGrupos() {
        System.out.println("Listar grupos:");

        
        int[] idsGrupos = {5, 6, 7, 8};
        String[] nomesGrupos = {"A", "B", "C", "D"};

        // Iterar sobre os grupos e listar as seleções de cada um
        for (int i = 0; i < idsGrupos.length; i++) {
            int idGrupo = idsGrupos[i];
            String nomeGrupo = nomesGrupos[i];
            List<Selecao> selecoes = selecaoDao.consultarPorGrupo(idGrupo);
            
            System.out.println("Seleções do Grupo " + nomeGrupo + ":");
            for (Selecao selecao : selecoes) {
                System.out.println("- ID: " + selecao.getId() + ", Nome: " + selecao.getNome());
            }
        }
    }



    private static void estatisticas() {
        System.out.println("...................Gerenciar Estatisticas..................");
        System.out.println("1. Estatísticas da Equipe");
        System.out.println("2. Estatísticas do Jogador");
        System.out.println("3. Voltar");

        int choice = InputUtils.getInt("Escolha uma opção: ");

        switch (choice) {
            case 1:
                consultarEstatisticasEquipe();
                break;
            case 2:
                consultarEstatisticasJogador();
                break;
            case 3:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }

    private static void consultarEstatisticasEquipe() {
        int idSelecao = InputUtils.getInt("ID da selecao: ");
        List<EstatisticasEquipe> estatisticas = estatisticasEquipeDao.consultarPorSelecaoId(idSelecao);
        for (EstatisticasEquipe estatistica : estatisticas) {
            System.out.println("Jogo ID: " + estatistica.getJogoId() + " - Remates: " + estatistica.getRemates() + " - Livres: " + estatistica.getLivres() + " - Foras de Jogo: " + estatistica.getForasDeJogo());
        }
    }

    private static void consultarEstatisticasJogador() {
        int idJogador = InputUtils.getInt("ID do jogador: ");
        List<EstatisticasJogador> estatisticas = estatisticasJogadorDao.consultarPorJogadorId(idJogador);
        
        if (estatisticas.isEmpty()) {
            System.out.println("Nenhuma estatística encontrada para o jogador com ID: " + idJogador);
        } else {
            for (EstatisticasJogador estatistica : estatisticas) {
                System.out.println("Estatísticas do jogador para o jogo ID: " + estatistica.getJogoId());
                System.out.println(" - Passes: " + estatistica.getPasses());
                System.out.println(" - Assistências: " + estatistica.getAssistencias());
                System.out.println(" - Remates: " + estatistica.getRemates());
                System.out.println(" - Minutos Jogados: " + estatistica.getMinutosJogados());
                System.out.println(); 
            }
        }
    }
}