package classe;

public @interface Override {

}
