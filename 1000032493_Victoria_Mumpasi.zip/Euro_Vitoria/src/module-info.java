module Euro_Vitoria {
    requires transitive java.sql;
    exports classe;
    exports DAO;
    exports conexao;
}
